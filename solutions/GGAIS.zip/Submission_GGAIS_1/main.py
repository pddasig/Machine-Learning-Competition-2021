"""
Created on Sun Feb 23 2022

@author: Zhiyu Hou
@email: houzhiyu474@163.com
@description: This is the main program for used method

School of Geosciences
China University of Petroleum East China, Shandong, CHINA

"""
import numpy as np
import pandas as pd
from prediction_vsh import pred_vsh
from prediction_phi import pred_phi
from prediction_sw import pred_sw
colnames = {"PHIF","SW","VSH"}
# predicting parametes
predvsh = pred_vsh()
predphi = pred_phi()
predsw = pred_sw()
output_result = np.concatenate([predphi.reshape(-1,1),predsw.reshape(-1,1),predvsh.reshape(-1,1)],axis=1)
output_result = np.where(output_result>1,np.ones_like(output_result),output_result)
output_result = pd.DataFrame(output_result,columns=colnames)
# Create output file
output_result.to_csv(path_or_buf=f'./submission.csv', index=False)