"""
Created on Sun Feb 23 2022

@author: Zhiyu Hou
@email: houzhiyu474@163.com
@description: This is the main program for predicting water saturation

School of Geosciences
China University of Petroleum East China, Shandong, CHINA

"""
from xgboost import XGBRegressor
from train_data_loader import trainloader
from test_data_loader import testloader
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np
def pred_sw():
    # Setting model parameters
    cv_params = {}
    other_params={'n_estimators': 30,'max_depth': 5,'min_child_weight': 8,'gamma': 0.0,'subsample': 0.4,'colsample_bytree': 1.0,'reg_lambda': 12.0,'reg_alpha': 0.0,'eta': 0.21544346900318834}
    # Preprocessing data (logarithmic)
    x_train,y_train = trainloader(["RMED","PHIF","SW"],1)
    x_train[:, 0]= np.log10(x_train[:, 0])
    # Defining model
    model = XGBRegressor(**other_params)
    # Adjusting model
    grid = GridSearchCV(estimator=model,param_grid=cv_params,scoring='neg_mean_squared_error',cv=5)
    # Training parameter
    grid.fit(x_train,y_train)
    RF1 = grid.best_estimator_
    # Predicting parameter
    X_val = testloader(["RMED"])
    X_val = np.log10(X_val)
    p = np.loadtxt("PHI.txt").reshape((-1, 1))
    X_val = np.concatenate([X_val, p], axis=1)
    output_result=RF1.predict(X_val)
    # Saving Results
    np.savetxt("SW.txt",output_result)
    return output_result
