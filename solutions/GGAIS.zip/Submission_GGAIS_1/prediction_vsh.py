"""
Created on Sun Feb 23 2022

@author: Zhiyu Hou
@email: houzhiyu474@163.com
@description: This is the main program for predicting water shale volume

School of Geosciences
China University of Petroleum East China, Shandong, CHINA

"""
from xgboost import XGBRegressor
from train_data_loader import trainloader
from test_data_loader import testloader
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import r2_score, mean_squared_error
import numpy as np
def pred_vsh():
    # Setting model parameters
    cv_params = {'eta': np.logspace(-2, 0, 10)}
    other_params={'n_estimators': 15,'max_depth': 4,'min_child_weight': 2,'gamma': 1.0,'subsample': 0.7,'colsample_bytree': 0.1,'reg_lambda': 0.0,'reg_alpha': 0.0,'eta': 0.3593813663804626}
    x_train,y_train = trainloader(["GR","VSH"],1)
    # Defining model
    model = XGBRegressor(**other_params)
    # Adjusting model
    grid = GridSearchCV(estimator=model,param_grid=cv_params,scoring='neg_mean_squared_error',cv=5)
    # Training parameter
    grid.fit(x_train,y_train)
    RF1 = grid.best_estimator_
    # Predicting parameter
    X_val = testloader(["GR"])
    output_result=RF1.predict(X_val)
    # Saving Results
    np.savetxt("VSH.txt",output_result)
    return output_result
