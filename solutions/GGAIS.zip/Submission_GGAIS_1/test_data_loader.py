"""
Created on Sun Feb 23 2022

@author: Zhiyu Hou
@email: houzhiyu474@163.com
@description: This is the main program for loading test data

School of Geosciences
China University of Petroleum East China, Shandong, CHINA

"""
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
def testloader(col_names):
    dftest = pd.read_csv('test.csv')
    dftest.replace(['-9999', -9999], np.nan, inplace=True)
    test_data = np.array(dftest.loc[:, col_names])
    imp_mean = SimpleImputer(missing_values=np.nan, strategy='mean')
    test_data = imp_mean.fit_transform(test_data)
    return test_data
