If you run on your Google Colab be sure to uncomment 19-21 lines of `Load libraries` section in 'notebook.ipynb'

```python
from google.colab import drive
drive.mount('/content/drive')
%cd /content/drive/My Drive/Colab Notebooks/SPWLA/notebooks
```

Otherwise do noting.